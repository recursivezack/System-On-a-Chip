library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity timer is
Port(
clk: in std_logic;
count_value: out std_logic_vector(31 downto 0)
);
end timer;

architecture Behavioral of timer is

    signal count : unsigned(31 downto 0) := (others => '0');

begin

    process(clk)
    begin
        if rising_edge(clk) then
            count <= count + 1;
        end if;
    end process;
    

    count_value <= std_logic_vector(count);
end Behavioral;
